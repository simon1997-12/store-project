package exceptions;

@SuppressWarnings("serial")
public class CartProductNotExistException extends Exception {

	public CartProductNotExistException() {
		super("product not exist");
	
	}
	

}
