package exceptions;

@SuppressWarnings("serial")
public class ProductQuantityNotAvailableException extends Exception  {

	public ProductQuantityNotAvailableException(int quantity)  {
		
		super("quantity: " + quantity + " is not available");
		
	}


	

}
