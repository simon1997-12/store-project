package exceptions;

@SuppressWarnings("serial")
public class CartProductAlreadyExistException extends Exception {

	public CartProductAlreadyExistException() {
		super("product exist in cart already, it is not avilable to add it again");

	}

}
