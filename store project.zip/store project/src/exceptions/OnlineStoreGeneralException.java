package exceptions;

@SuppressWarnings("serial")
public class OnlineStoreGeneralException extends Exception {

	public OnlineStoreGeneralException(int id) {
		super("id: " + id +  " does not exist in stock");
		
	}
	

}
