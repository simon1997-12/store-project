package exceptions;

@SuppressWarnings("serial")
public class ReachedMaxAmountException extends Exception {

	public ReachedMaxAmountException() {
		super(" reached max amount of products in cart ");
		
	}

}
