import java.io.IOException;

import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import exceptions.ReachedMaxAmountException;

public interface Reservable {

	void reserve(int amount, int id, OnlineStore store) throws OnlineStoreGeneralException,
			CartProductAlreadyExistException, ReachedMaxAmountException, ProductQuantityNotAvailableException,
			CloneNotSupportedException, ClassNotFoundException, IOException, CartProductNotExistException;

}
