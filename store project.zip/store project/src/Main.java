
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.Scanner;
import exceptions.ReachedMaxAmountException;
import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Main {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// OnlineStore stock = readFromFile2("products_list2.csv");
		// saveStock(stock,"stock.dat5");
		OnlineStore stock = readStock("stock.dat5");

		Scanner s = new Scanner(System.in);
		int choice = 0;
		do {
			displayMenu();

			System.out.println("Enter your choice (1-7): ");
			choice = s.nextInt();
			switch (choice) {
			case 1:

				System.out.println("The products in stock are:");
				System.out.println();
				stock.showProducts();

				System.out.println();
				System.out.println("There is " + stock.numOfItemsInCart() + " items in your shopping cart");

				break;

			case 2:
				stock.showCart();

				break;
			case 3:

				System.out.println("Available stock:");
				stock.showSuggestion();

				System.out.println("Enter the id of the product you want to add: ");
				Scanner s2 = new Scanner(System.in);

				try {
					int id = s2.nextInt();
					stock.addToCart(id);

				} catch (OnlineStoreGeneralException e) {
					System.out.println(e.getMessage());
				} catch (CartProductAlreadyExistException e) {
					System.out.println(e.getMessage());
				} catch (InputMismatchException e) {
					System.out.println("unvalid input, should be a number between 1-30");
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				saveStock(stock, "stock.dat5");

				break;
			case 4:

				Scanner s3 = new Scanner(System.in);
				System.out.println("Enter the id of the product:");
				try {
					int id2 = s3.nextInt();
					stock.ifisExistInCart(id2);
					System.out.println("Enter the new quantity of the product you want  change to:");
					int num = s3.nextInt();
					for (int i = 0; i < stock.getNumOfItemsInCart(); i++) {
						if (stock.getCartProducts()[i] instanceof Reservable) {
							((Reservable) stock.getCartProducts()[i]).reserve(num, id2, stock);

						}
					}

				} catch (ProductQuantityNotAvailableException e) {
					System.out.println(e.getMessage());
				} catch (ReachedMaxAmountException e) {
					System.out.println(e.getMessage());
				} catch (CartProductNotExistException e) {
					System.out.println(e.getMessage());
				} catch (InputMismatchException e) {
					System.out.println("unvalid input, should be a number between 1-30");
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				saveStock(stock, "stock.dat5");
				break;
			case 5:
				Scanner s4 = new Scanner(System.in);

				System.out.println("Shopping cart:");
				stock.showCart();

				try {
					System.out.println("\nEnter the id of the product you want to remove: ");

					int RemoveProduct1 = s4.nextInt();
					stock.QuantityUpdate(RemoveProduct1, 0);
				} catch (ProductQuantityNotAvailableException e) {
					e.getMessage();
				} catch (InputMismatchException e) {
					System.out.println("unvalid input, should be a number between 1-30");

				} catch (CartProductNotExistException e) {
					System.out.println(e.getMessage());

				} catch (Exception e) {
					System.out.println(e.getMessage());

				}
				saveStock(stock, "stock.dat5");

				break;

			case 6:
				Scanner s5 = new Scanner(System.in);
				try {
					System.out.println("enter the number of the desire option (1.name/2.quantity/3.category)");
					int option = s5.nextInt();
					Product[] copyStock = stock.getOriginalStock();
					if (option < 1 || option > 3) {
						System.out.println("unvalid option, should be a number between 1-3");
					}
					if (option == 1) {
						bubbleSort(copyStock, new CompareProductsByName());
						System.out.println("sorted by name: ");
						System.out.println();
						for (int i = 0; i < copyStock.length; i++) {
							System.out.println(copyStock[i].toString());
						}
					} else if (option == 2) {
						bubbleSort(copyStock, new CompareProductsByQuantity());
						System.out.println("sorted by quantity: ");
						System.out.println();
						for (int i = 0; i < copyStock.length; i++) {
							System.out.println(copyStock[i].toString());
						}
					} else if (option == 3) {
						bubbleSort(copyStock, new CompareProductsByCategory());
						System.out.println("sorted by category: ");
						System.out.println();
						for (int i = 0; i < copyStock.length; i++) {
							System.out.println(copyStock[i].toString());
						}
					}

				} catch (InputMismatchException e) {
					System.out.println("unvalid option,should be  a number between 1-3");
				}
				saveStock(stock, "stock.dat5");

				break;
			case 7:
				saveStock(stock, "stock.dat5");
				System.out.println("Exit program");
				break;
			default:

				System.out.println("Invalid input");
				break;
			}
		} while (choice != 7);
		saveStock(stock, "stock.dat5");
		s.close();

	}

	private static void displayMenu() {
		System.out.println("\n===== MENU =====");
		System.out.println("1. Display stock and quantity of products in shopping cart");
		System.out.println("2. show Shopping cart");
		System.out.println("3. Add product to shopping cart");
		System.out.println("4. Update quantity of product in Shopping cart");
		System.out.println("5. Remove product from shopping cart");
		System.out.println("6. Sort  stock by name/quantity/category");
		System.out.println("7. Exit program");
	}

	public static OnlineStore readFromFile2(String fileName) throws NumberFormatException, IOException {
		String File = fileName;
		BufferedReader br = new BufferedReader(new FileReader(File));
		String line = br.readLine();
		int index = 0;
		int rows = 0;

		while ((line = br.readLine()) != null) {
			String[] productData = line.split(",");
			if (productData.length == 6 || productData.length == 5) {

				rows++;

			}
		}
		OnlineStore onlineStore = new OnlineStore(rows);
		br.close();

		String File1 = fileName;
		BufferedReader br1 = new BufferedReader(new FileReader(File1));
		String line1 = br1.readLine();

		while ((line1 = br1.readLine()) != null) {
			String[] productData = line1.split(",");
			String productCategory = productData[0];
			String productName = productData[1];
			int quantity = Integer.parseInt(productData[2]);

			if (productCategory.equalsIgnoreCase("Books")) {
				String authorName = productData[3];
				int numOfPages = Integer.parseInt(productData[4]);
				Product p = new Books(productName, quantity, Product.Category.Books, authorName, numOfPages);
				onlineStore.setProduct(index, p);

				index++;
			}

		}
		br1.close();
		String File2 = fileName;
		BufferedReader br2 = new BufferedReader(new FileReader(File2));
		String line2 = br2.readLine();

		while ((line2 = br2.readLine()) != null) {
			String[] productData = line2.split(",");

			String productCategory = productData[0];
			String productName = productData[1];
			int quantity = Integer.parseInt(productData[2]);

			if (productCategory.equalsIgnoreCase("Clothing")) {
				String clothSize = productData[3];
				String color = productData[4];
				String gender = productData[5];
				Product p1 = new Clothing(productName, quantity, Product.Category.Clothing, clothSize, color, gender);
				onlineStore.setProduct(index, p1);

				index++;

			}
		}
		br2.close();
		String File3 = fileName;
		BufferedReader br3 = new BufferedReader(new FileReader(File3));
		String line3 = br3.readLine();
		while ((line3 = br3.readLine()) != null) {
			String[] productData = line3.split(",");
			String productCategory = productData[0];
			String productName = productData[1];
			int quantity = Integer.parseInt(productData[2]);
			if (productCategory.equalsIgnoreCase("Electronics")) {
				String brand = productData[3];
				String model = productData[4];
				Product p2 = new Electronics(productName, quantity, Product.Category.Electronics, brand, model);
				onlineStore.setProduct(index, p2);
				index++;

			}

		}
		br3.close();

		return onlineStore;
	}

	private static void saveStock(OnlineStore stock, String filename) throws IOException {
		ObjectOutputStream file = new ObjectOutputStream(new FileOutputStream(filename));
		file.writeObject(stock);
		file.close();
	}

	static OnlineStore readStock(String filename) throws IOException, ClassNotFoundException {
		ObjectInputStream file = new ObjectInputStream(new FileInputStream(filename));
		OnlineStore stock = (OnlineStore) file.readObject();

		file.close();
		return stock;
	}

	public static void bubbleSort(Object[] arr, Comparator c) {
		for (int i = arr.length - 1; i > 0; i--) {
			for (int j = 0; j < i; j++) {
				if (c.compare(arr[j], arr[j + 1]) > 0) {
					Object temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}
			}
		}
	}

}
