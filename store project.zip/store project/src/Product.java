import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import exceptions.ReachedMaxAmountException;

public  class Product implements Reservable, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8770354481423522166L;
	private static int counter;
	protected final String name;
	protected final int id;
	protected int quantity;

	public enum Category {
		Books, Clothing, Electronics
	};

	protected Category category;
	private String date;
	private String updateDate;

	public Product(String name, int quantity, Category category) {

		this.name = name;
		this.quantity = quantity;
		id = ++counter;
		this.category = category;
	}

	public Product(String name, int id, int quantity, Category category, String date, String updateDate) {
		this.name = name;
		this.id = id;
		this.quantity = quantity;
		this.category = category;
		this.date = date;
		this.updateDate = updateDate;

	}

	public Product(String name, int id, int quantity, Category category) {
		this.name = name;
		this.id = id;
		this.quantity = quantity;
		this.category = category;

	}

	public Product(Product other) {
		this.name = other.name;
		this.id = other.id;
		this.quantity = other.quantity;
		this.category = other.category;

	}

	public String getNowDate() {
		DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy 'at' hh:mm    a");
		return FOMATTER.format(LocalDateTime.now());
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public String getDate() {

		return date;
	}

	public Category getCategory() {

		return category;
	}

	public String getName() {

		return name;
	}

	public int getQuantity() {

		return quantity;
	}

	public void setQuantity(int quantity) {

		this.quantity = quantity;
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return String.format("id:%-3d |category:%-25s |name:%-40s  |quantity:%-15d", id, category, name, quantity);

	}

	@Override
	public void reserve(int num, int id, OnlineStore stock)
			throws OnlineStoreGeneralException, CartProductAlreadyExistException, ReachedMaxAmountException,
			ProductQuantityNotAvailableException, ClassNotFoundException, IOException, CartProductNotExistException {
		if (stock.getCategoryById(id).equals(Category.Electronics) && num > 3) {
			System.out.println("max amount from Electronics in cart is 3 ");
			return;
		}

		if (stock.cart.isExist(id)) {
			if (num < 0 || stock.getQuantityOfProductInStock(id) < num) {
				throw new ProductQuantityNotAvailableException(num);
			}
			for (int i = 0; i < stock.getNumOfAvailableItems(); i++) {

				if (stock.getProducts()[i].getId() == id && stock.getProducts()[i].getQuantity() >= num) {
					stock.getOriginalStock()[i].setQuantity((stock.getProducts()[i].quantity) - num);
					stock.cart.changeQuantity(id, num);
					if (num != 0) {
						stock.changeUpdateDate(stock.cart.getCartProductById(id), getNowDate());
						System.out.println("Quantity updated ");
						break;
					} else {
						stock.getOriginalStock()[i].setQuantity(stock.getProducts()[i].getQuantity());
					}
				}

			}

		} else {
			throw new CartProductNotExistException();

		}

	}

}
