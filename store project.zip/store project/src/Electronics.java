import java.io.IOException;
import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import exceptions.ReachedMaxAmountException;

public class Electronics extends Product {
	/**
	 * 
	 */
	private static final long serialVersionUID = -27825343668339484L;
	private String brand;
	private String model;

	public Electronics(String name, int quantity, Product.Category category, String brand, String model) {
		super(name, quantity, category);
		this.brand = brand;
		this.model = model;
	}

	@Override
	public String toString() {
		return super.toString() + String.format("|brand:%-31s  |model:%-20s ", brand, model);
	}

	@Override
	public void reserve(int amount, int id, OnlineStore store)
			throws OnlineStoreGeneralException, CartProductAlreadyExistException, ReachedMaxAmountException,
			ProductQuantityNotAvailableException, ClassNotFoundException, IOException, CartProductNotExistException {
		if (amount > 3 || amount < 0) {
			System.out.println("max amount 3 ");
		} else {
			super.reserve(amount, id, store);
		}

	}

}
