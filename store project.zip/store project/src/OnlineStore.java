import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import exceptions.ReachedMaxAmountException;
import java.io.Serializable;

public class OnlineStore implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6593392026481787323L;
	private Product[] originalStock;
	private Product[] products;
	Cart cart;
	private int NumOfAvailableItems;

	public OnlineStore(int length) {
		this.products = new Product[length];
		this.originalStock = new Product[length];
		this.cart = new Cart();

		this.NumOfAvailableItems = length;
	}

	public Product[] getCartProducts() {
		return cart.getCartProducts();
	}

	public Product[] getProducts() {
		return products;
	}

	public void showSuggestion() {
		for (int i = 0; i < NumOfAvailableItems; i++) {
			if (!cart.isExist(products[i].getId())) {
				System.out.println(products[i].toString());
			}
		}
	}

	public int getQuantityOfProductInStock(int id) {
		for (int i = 0; i < products.length; i++) {
			if (products[i].getId() == id) {
				return products[i].getQuantity();
			}

		}
		return 0;

	}

	public void setProduct(int index, Product product) {
		originalStock[index] = product;
		products[index] = new Product(product);

	}

	public void showCart() {
		cart.showProducts();

	}

	public int getNumOfAvailableItems() {

		return NumOfAvailableItems;
	}

	public void addToCart(int id)
			throws OnlineStoreGeneralException, CartProductAlreadyExistException, ReachedMaxAmountException {

		if (!isExist(id)) {
			throw new OnlineStoreGeneralException(id);

		} else if (cart.isExist(id)) {
			throw new CartProductAlreadyExistException();

		} else {
			cart.addToCart(getNameById(id), id, getCategoryById(id), getDate(), "not Updated");
			changeQuantity(id, -1);
			System.out.println("item added successfuly at: " + getDate());

		}
	}

	public void changeUpdateDate(Product product, String date) {
		product.setUpdateDate(date);
	}

	public String getDate() {
		DateTimeFormatter FOMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy 'at' hh:mm    a");
		return FOMATTER.format(LocalDateTime.now());
	}

	public Product.Category getCategoryById(int id) {
		for (int i = 0; i < products.length; i++) {
			if (products[i].getId() == id) {
				return products[i].getCategory();
			}
		}

		return null;
	}

	public void ifisExistInCart(int id) throws CartProductNotExistException {
		if (!cart.isExist(id)) {

			throw new CartProductNotExistException();
		}

	}

	public void QuantityUpdate(int id, int num)
			throws ProductQuantityNotAvailableException, ReachedMaxAmountException, CartProductNotExistException {

		if (cart.isExist(id)) {
			if (num < 0 || getQuantityOfProductInStock(id) < num) {
				throw new ProductQuantityNotAvailableException(num);
			}
			for (int i = 0; i < NumOfAvailableItems; i++) {

				if (products[i].getId() == id && products[i].getQuantity() >= num) {
					originalStock[i].setQuantity(products[i].getQuantity() - num);
					cart.changeQuantity(id, num);
					if (num != 0) {
						changeUpdateDate(cart.getCartProductById(id), getDate());
						System.out.println("Quantity updated ");
					} else {
						originalStock[i].setQuantity(products[i].getQuantity());
					}
				}

			}

		} else {
			throw new CartProductNotExistException();

		}

	}

	public int numOfItemsInCart() {
		return cart.getNumOfSaveItems();
	}

	public void changeQuantity(int id, int num) {
		for (int i = 0; i < NumOfAvailableItems; i++) {
			if (originalStock[i].getId() == id) {
				originalStock[i].setQuantity(originalStock[i].getQuantity() + num);
				return;
			}
		}

	}

	public String getNameById(int id) {
		for (int i = 0; i < NumOfAvailableItems; i++) {
			if (products[i].getId() == id) {
				return products[i].getName();
			}
		}

		return "";
	}

	public boolean isExist(int id) {

		for (int i = 0; i < NumOfAvailableItems; i++) {
			if (products[i].getId() == id) {
				return true;
			}
		}
		return false;
	}

	public void showProducts() {
		for (int i = 0; i < originalStock.length; i++) {
			System.out.println(originalStock[i].toString());
		}
	}

	public int getNumOfItemsInCart() {

		return cart.getNumOfSaveItems();
	}

	public Product[] getOriginalStock() {
		return originalStock;
	}

}
