import java.io.IOException;

import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import exceptions.ReachedMaxAmountException;

public class Books extends Product {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2059855911860504229L;
	private String authorName;
	private int NumOfPages;

	public Books(String name, int quantity, Product.Category category, String authorName, int numOfPages) {
		super(name, quantity, category);
		this.authorName = authorName;
		NumOfPages = numOfPages;
	}

	@Override
	public String toString() {
		return super.toString() + String.format("|authorName:%-25s   |NumOfPages:%-12d  ", authorName, NumOfPages);
	}

	@Override
	public void reserve(int amount, int id, OnlineStore store)
			throws OnlineStoreGeneralException, CartProductAlreadyExistException, ReachedMaxAmountException,
			ProductQuantityNotAvailableException, ClassNotFoundException, IOException, CartProductNotExistException {
		super.reserve(amount, id, store);

	}

}
