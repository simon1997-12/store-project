import java.io.Serializable;
import java.util.Arrays;
import exceptions.ReachedMaxAmountException;

public class Cart implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2949956177161992802L;
	private Product[] cartProducts;
	private int NumOfSaveItemsInCart;
	private final int maxAmountOfSaveItemsInCart;

	public Cart() {

		this.cartProducts = new Product[0];
		NumOfSaveItemsInCart = 0;
		maxAmountOfSaveItemsInCart = 9;
	}

	public Product[] getCartProducts() {
		return cartProducts;
	}

	public void showProducts() {
		if (cartProducts.length == 0 || NumOfSaveItemsInCart == 0) {
			System.out.println("Cart is empty ");
		}
		for (int i = 0; i < NumOfSaveItemsInCart; i++) {
			System.out.println(cartProducts[i].toString() + "|add Date: " + cartProducts[i].getDate()
					+ "       |update Date: " + cartProducts[i].getUpdateDate());

		}

	}

	public void changeQuantity(int id, int num) {
		for (int i = 0; i < cartProducts.length; i++) {
			if (cartProducts[i].getId() == id) {
				if (num == 0) {
					RemoveFromCart(id);

					System.out.println("Product removed");
					if (cartProducts.length == 0) {
						NumOfSaveItemsInCart = 0;
					}
				} else {
					cartProducts[i].setQuantity(num);
				}
			}
		}

	}

	public Product getCartProductById(int id) {
		for (int i = 0; i < cartProducts.length; i++) {
			if (cartProducts[i].getId() == id) {
				return cartProducts[i];
			}

		}
		return null;
	}

	public boolean isExist(int id) {
		for (int i = 0; i < NumOfSaveItemsInCart; i++) {
			if (cartProducts[i].getId() == id) {
				return true;
			}
		}
		return false;
	}

	public void addToCart(String itemName, int id, Product.Category category, String date, String updateDate)
			throws ReachedMaxAmountException {
		if (NumOfSaveItemsInCart >= maxAmountOfSaveItemsInCart) {
			throw new ReachedMaxAmountException();
		}
		NumOfSaveItemsInCart++;
		cartProducts = Arrays.copyOf(cartProducts, NumOfSaveItemsInCart);
		cartProducts[NumOfSaveItemsInCart - 1] = new Product(itemName, id, 1, category, date, updateDate);

	}

	public void RemoveFromCart(int id) {

		for (int i = 0; i < NumOfSaveItemsInCart; i++) {
			if (cartProducts[i].getId() == id) {
				cartProducts[i] = cartProducts[--NumOfSaveItemsInCart];

			}

		}

	}

	public int getNumOfSaveItems() {
		if (cartProducts == null) {
			return 0;

		} else {

			return NumOfSaveItemsInCart;
		}
	}

	@Override
	public String toString() {
		return "Cart [cartProducts=" + Arrays.toString(cartProducts) + ", NumOfSaveItems=" + NumOfSaveItemsInCart + "]";
	}

}
