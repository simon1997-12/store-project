import java.io.IOException;

import exceptions.CartProductAlreadyExistException;
import exceptions.CartProductNotExistException;
import exceptions.OnlineStoreGeneralException;
import exceptions.ProductQuantityNotAvailableException;
import exceptions.ReachedMaxAmountException;

public class Clothing extends Product {
	/**
	 * 
	 */
	private static final long serialVersionUID = -478613034084086172L;
	private String size;
	private String color;
	private String gender;

	public Clothing(String name, int quantity, Product.Category category, String size, String color, String gender) {
		super(name, quantity, category);
		this.size = size;
		this.color = color;
		this.gender = gender;

	}

	@Override
	public String toString() {
		return super.toString() + String.format("|size:%-32s  |gender:%-20s |color:%-35s", size, gender, color);
	}

	@Override
	public void reserve(int amount, int id, OnlineStore store)
			throws OnlineStoreGeneralException, CartProductAlreadyExistException, ReachedMaxAmountException,
			ProductQuantityNotAvailableException, ClassNotFoundException, IOException, CartProductNotExistException {
		super.reserve(amount, id, store);

	}

}
